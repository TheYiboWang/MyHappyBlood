var require = meteorInstall({"lib":{"reminderdb.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// lib/reminderdb.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
PastReminders = new Mongo.Collection("past_reminders");                                                        // 1
                                                                                                               //
if (Meteor.isServer) {                                                                                         // 4
  Meteor.publish('PastReminders', function tasksPublication() {                                                // 5
    return PastReminders.find();                                                                               // 6
  });                                                                                                          // 7
}                                                                                                              // 8
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"api":{"Login.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/api/Login.js                                                                                         //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var postSignUpFunc = function postSignUpFunc(userId, info) {                                                   // 1
  Meteor.users.update({ _id: userId }, { $set: { profile: info.profile } });                                   // 2
};                                                                                                             // 3
                                                                                                               //
AccountsTemplates.configure({                                                                                  // 5
  postSignUpHook: postSignUpFunc                                                                               // 6
});                                                                                                            // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"account-creation.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/api/account-creation.js                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});//account-creation.js  //
                                                                                                               //
                                                                                                               // 3
                                                                                                               //
//set more fields during registration                                                                          //
Accounts.onCreateUser(function (options, user) {                                                               // 6
    user.surveyData = []; //initialize to an empty array                                                       // 7
                                                                                                               //
    user.INRhistory = []; //initialize to an empty array                                                       // 9
                                                                                                               //
    // Don't forget to return the new user object at the end!                                                  //
    return user;                                                                                               // 12
});                                                                                                            // 13
                                                                                                               //
//publish the non-default userdata (age, gender, medicineHistory,                                              //
//INRhistory and EatingPlan) to client                                                                         //
Meteor.publish("userData", function () {                                                                       // 17
    var currentUser = this.userId;                                                                             // 18
    if (currentUser) {                                                                                         // 19
        return Meteor.users.find(currentUser, {                                                                // 20
            fields: {                                                                                          // 21
                surveyData: 1,                                                                                 // 22
                                                                                                               //
                INRhistory: 1,                                                                                 // 24
                                                                                                               //
                profile: 1,                                                                                    // 26
                                                                                                               //
                notifData: 1                                                                                   // 28
            }                                                                                                  // 21
        });                                                                                                    // 20
    } else {                                                                                                   // 31
        return this.ready();                                                                                   // 33
    }                                                                                                          // 34
});                                                                                                            // 35
                                                                                                               //
//Allow client to update users collections                                                                     //
Meteor.users.allow({                                                                                           // 38
    update: function update(userId, doc, fields, modifier) {                                                   // 39
        return true;                                                                                           // 40
    }                                                                                                          // 41
});                                                                                                            // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pushMethods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/api/pushMethods.js                                                                                   //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Push.debug = true;                                                                                             // 1
                                                                                                               //
Push.allow({                                                                                                   // 3
    send: function send(userId, notification) {                                                                // 4
        return true; // Allow all users to send                                                                // 5
    }                                                                                                          // 6
});                                                                                                            // 3
                                                                                                               //
Meteor.methods({                                                                                               // 9
    serverNotification: function serverNotification(text, title) {                                             // 10
        var badge = 1;                                                                                         // 11
        Push.send({                                                                                            // 12
            from: 'push',                                                                                      // 13
            title: title,                                                                                      // 14
            text: text,                                                                                        // 15
            badge: badge, //optional, use it to set badge count of the receiver when the app is in background.
            query: {} // Query the appCollection                                                               // 17
            // token: appId or token eg. "{ apn: token }"                                                      //
            // tokens: array of appId's or tokens                                                              //
            // payload: user data                                                                              //
            // delayUntil: Date                                                                                //
        });                                                                                                    // 12
    },                                                                                                         // 24
    userNotification: function userNotification(text, title, userId) {                                         // 25
        var badge = 1;                                                                                         // 26
        Push.send({                                                                                            // 27
            from: 'push',                                                                                      // 28
            title: title,                                                                                      // 29
            text: text,                                                                                        // 30
            badge: badge,                                                                                      // 31
            sound: 'airhorn.caf',                                                                              // 32
            payload: {                                                                                         // 33
                title: title,                                                                                  // 34
                historyId: result                                                                              // 35
            },                                                                                                 // 33
            query: {                                                                                           // 37
                userId: userId //this will send to a specific Meteor.user()._id                                // 38
            }                                                                                                  // 37
        });                                                                                                    // 27
    },                                                                                                         // 41
    removeHistory: function removeHistory() {                                                                  // 42
        NotificationHistory.remove({}, function (error) {                                                      // 43
            if (!error) {                                                                                      // 44
                console.log("All history removed");                                                            // 45
            }                                                                                                  // 46
        });                                                                                                    // 47
    }                                                                                                          // 48
});                                                                                                            // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":["meteor/meteor","meteor/http",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var HTTP;module.import('meteor/http',{"HTTP":function(v){HTTP=v}});
                                                                                                               // 2
                                                                                                               //
function _send_info() {                                                                                        // 5
        var PatientsInfo = Meteor.users.find().fetch();                                                        // 6
        console.log("sending Patients Information");                                                           // 7
                                                                                                               //
        // This url serves as a web API. You can choose your own path to form a protocol.                      //
        // Notice that I use JSON as content type, you can use other content type according to your need.      //
        // Also, make sure to run the receiver app on port 3002.                                               //
        var url = "http://localhost:3002/patients-update";                                                     // 12
        var result = HTTP.post(url, {                                                                          // 13
                headers: {                                                                                     // 14
                        "content-type": "application/json; charset=UTF-8"                                      // 15
                },                                                                                             // 14
                content: JSON.stringify(PatientsInfo)                                                          // 17
        });                                                                                                    // 13
        console.log("Patients Information sended");                                                            // 19
}                                                                                                              // 20
                                                                                                               //
var c_Methods = {                                                                                              // 22
        send_info: function send_info(arg) {                                                                   // 23
                _send_info();                                                                                  // 24
        }                                                                                                      // 25
};                                                                                                             // 22
                                                                                                               //
Router.route("/patients-update", { where: "server" }).post(function () {                                       // 28
        // retrieve data                                                                                       //
        var patients = this.request.body;                                                                      // 30
        // needs to end with a response so the other server doesn't hang.                                      //
        this.response.end("Patients recieved");                                                                // 32
                                                                                                               //
        for (var i = 0; i < patients.length; i++) {                                                            // 34
                Meteor.users.update({ _id: patients[i]["_id"] }, { $set: {                                     // 35
                                profile: patients[i]["profile"] }                                              // 36
                });                                                                                            // 35
        }                                                                                                      // 38
});                                                                                                            // 39
                                                                                                               //
Meteor.startup(function () {                                                                                   // 41
        // Register a meteor method for the client to call on.                                                 //
        Meteor.methods(c_Methods);                                                                             // 43
});                                                                                                            // 44
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"startup":{"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// startup/routes.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
// routes.js                                                                                                   //
if (Meteor.isClient) {                                                                                         // 2
  Router.onBeforeAction(function () {                                                                          // 3
    // all properties available in the route function                                                          //
    // are also available here such as this.params                                                             //
                                                                                                               //
    if (!Meteor.userId()) {                                                                                    // 7
      // if the user is not logged in, render the Login template                                               //
                                                                                                               //
      this.render('login');                                                                                    // 10
    } else {                                                                                                   // 11
      // otherwise don't hold up the rest of hooks or our route/action function                                //
      // from running                                                                                          //
      this.next();                                                                                             // 14
    }                                                                                                          // 15
  });                                                                                                          // 16
}                                                                                                              // 17
                                                                                                               //
Router.route('/', function () {                                                                                // 19
  this.render('home');                                                                                         // 20
});                                                                                                            // 22
                                                                                                               //
Router.route('/home', function () {                                                                            // 24
  this.render('home');                                                                                         // 25
  Meteor.call("send_info");                                                                                    // 26
});                                                                                                            // 27
                                                                                                               //
Router.route('/helppage', function () {                                                                        // 30
  this.render('helppage');                                                                                     // 31
});                                                                                                            // 32
                                                                                                               //
Router.route('/profile', function () {                                                                         // 34
  this.render('profile');                                                                                      // 35
});                                                                                                            // 36
                                                                                                               //
Router.route('/myprogress', function () {                                                                      // 38
  this.render('myprogress');                                                                                   // 39
});                                                                                                            // 40
                                                                                                               //
Router.route('/mycondition', function () {                                                                     // 42
  this.render('conditionhistory');                                                                             // 43
});                                                                                                            // 44
                                                                                                               //
Router.route('/mylearningpage', function () {                                                                  // 46
  this.render('mylearningpage');                                                                               // 47
});                                                                                                            // 48
Router.route('/mymedspage', function () {                                                                      // 49
  this.render('mymedspage');                                                                                   // 50
});                                                                                                            // 51
Router.route('/mysurveypage', function () {                                                                    // 52
  this.render('mysurveypage');                                                                                 // 53
});                                                                                                            // 54
Router.route('/helpInstructions', function () {                                                                // 55
  this.render('helpInstructions');                                                                             // 56
});                                                                                                            // 57
Router.route('/warfarin/', function () {                                                                       // 58
  this.render('mylearningWarfarin');                                                                           // 59
});                                                                                                            // 60
Router.route('/othermeds/', function () {                                                                      // 61
  this.render('mylearningOtherMeds');                                                                          // 62
});                                                                                                            // 63
                                                                                                               //
Router.route('/newmeds/', function () {                                                                        // 66
  this.render('mylearningNewMeds');                                                                            // 67
});                                                                                                            // 68
Router.route('/generalInfo/', function () {                                                                    // 69
  this.render('generalinformation');                                                                           // 70
});                                                                                                            // 71
Router.route('/Apixaban/', function () {                                                                       // 72
  this.render('Apixaban');                                                                                     // 73
});                                                                                                            // 74
Router.route('/Dabigatran/', function () {                                                                     // 75
  this.render('Dabigatran');                                                                                   // 76
});                                                                                                            // 77
Router.route('/Rivaroxaban/', function () {                                                                    // 78
  this.render('Rivaroxaban');                                                                                  // 79
});                                                                                                            // 80
                                                                                                               //
Router.route('/warning/', function () {                                                                        // 83
  this.render('mylearningWarning');                                                                            // 84
});                                                                                                            // 85
                                                                                                               //
Router.route('/safetytips/', function () {                                                                     // 88
  this.render('mylearningSafety');                                                                             // 89
});                                                                                                            // 90
                                                                                                               //
Router.route('/setupPushReminder/', function () {                                                              // 92
  this.render('setupPushReminder');                                                                            // 93
});                                                                                                            // 94
Router.route('/addReminder/', function () {                                                                    // 95
  this.render('addReminder');                                                                                  // 96
});                                                                                                            // 97
                                                                                                               //
// Router.route('mylearningWarfarin', {                                                                        //
//   // get parameter via this.params                                                                          //
//   path: '/mylearningpage/warfarin'                                                                          //
// });                                                                                                         //
                                                                                                               //
// Router.route('mylearningWarfarinDiet', {                                                                    //
//   path: '/mylearningpage/diet'                                                                              //
// });                                                                                                         //
Router.route('/addinr', function () {                                                                          // 107
  this.render('addinr');                                                                                       // 108
});                                                                                                            // 109
                                                                                                               //
Router.route('/thankyou', function () {                                                                        // 111
  this.render('thankyou');                                                                                     // 112
});                                                                                                            // 113
                                                                                                               //
Router.route('/inrhistory', function () {                                                                      // 115
  this.render('inrhistory');                                                                                   // 116
});                                                                                                            // 117
Router.route('/medhistory', function () {                                                                      // 118
  this.render('medhistory');                                                                                   // 119
});                                                                                                            // 120
Router.route('/mealshistory', function () {                                                                    // 121
  this.render('mealshistory');                                                                                 // 122
});                                                                                                            // 123
Router.route('/video', function () {                                                                           // 124
  this.render('video');                                                                                        // 125
});                                                                                                            // 126
                                                                                                               //
Router.route('/contact', function () {                                                                         // 128
  this.render('contact');                                                                                      // 129
});                                                                                                            // 130
Router.route('/aboutus', function () {                                                                         // 131
  this.render('aboutus');                                                                                      // 132
});                                                                                                            // 133
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"push.config.os.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// push.config.os.js                                                                                           //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
Meteor.startup(function() {
	Push.Configure({
	"apn": {
		"keyData": Assets.getText('MHB_Mobile.pem'),
		"certData": Assets.getText('aps_development.pem'),
		"passphrase": "MingHuang.MyHappyBlood"
	},
	"gcm": {
		"apiKey": "AIzaSyBw3mnVPrbdHkXvgI8uZG3bNl-n0c26eGo"
	},
	"production": true
});
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},{"extensions":[".js",".json"]});
require("./lib/reminderdb.js");
require("./server/api/Login.js");
require("./server/api/account-creation.js");
require("./server/api/pushMethods.js");
require("./startup/routes.js");
require("./push.config.os.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
