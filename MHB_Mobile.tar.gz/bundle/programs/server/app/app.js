var require = meteorInstall({"lib":{"reminderdb.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// lib/reminderdb.js                                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
PastReminders = new Mongo.Collection("past_reminders");                                                            // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"api":{"Login.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/api/Login.js                                                                                             //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var postSignUpFunc = function postSignUpFunc(userId, info) {                                                       // 1
  Meteor.users.update({ _id: userId }, { $set: { profile: info.profile } });                                       // 2
};                                                                                                                 // 3
                                                                                                                   //
AccountsTemplates.configure({                                                                                      // 5
  postSignUpHook: postSignUpFunc                                                                                   // 6
});                                                                                                                // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"account-creation.js":["meteor/accounts-base",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/api/account-creation.js                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Accounts;module.import('meteor/accounts-base',{"Accounts":function(v){Accounts=v}});//account-creation.js      //
                                                                                                                   //
                                                                                                                   // 3
                                                                                                                   //
//set more fields during registration                                                                              //
Accounts.onCreateUser(function (options, user) {                                                                   // 6
    user.surveyData = []; //initialize to an empty array                                                           // 7
                                                                                                                   //
    user.INRhistory = []; //initialize to an empty array                                                           // 9
                                                                                                                   //
    // Don't forget to return the new user object at the end!                                                      //
    return user;                                                                                                   // 12
});                                                                                                                // 13
                                                                                                                   //
//publish the non-default userdata (age, gender, medicineHistory,                                                  //
//INRhistory and EatingPlan) to client                                                                             //
Meteor.publish("userData", function () {                                                                           // 17
    var currentUser = this.userId;                                                                                 // 18
    if (currentUser) {                                                                                             // 19
        return Meteor.users.find(currentUser, {                                                                    // 20
            fields: {                                                                                              // 21
                surveyData: 1,                                                                                     // 22
                                                                                                                   //
                INRhistory: 1,                                                                                     // 24
                                                                                                                   //
                profile: 1,                                                                                        // 26
                                                                                                                   //
                notifData: 1                                                                                       // 28
            }                                                                                                      // 21
        });                                                                                                        // 20
    } else {                                                                                                       // 31
        return this.ready();                                                                                       // 33
    }                                                                                                              // 34
});                                                                                                                // 35
                                                                                                                   //
//Allow client to update users collections                                                                         //
Meteor.users.allow({                                                                                               // 38
    update: function update(userId, doc, fields, modifier) {                                                       // 39
        return true;                                                                                               // 40
    }                                                                                                              // 41
});                                                                                                                // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pushMethods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/api/pushMethods.js                                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
Meteor.methods({                                                                                                   // 1
    serverNotification: function serverNotification() {                                                            // 2
                                                                                                                   //
        var last = PastReminders.findOne({}, { sort: { addedAt: -1 } });                                           // 4
        var badge = 1;                                                                                             // 5
        if (last != null) {                                                                                        // 6
            badge = last.badge + 1;                                                                                // 7
        }                                                                                                          // 8
                                                                                                                   //
        //Use find() function to get the user defined notifData and trigger the notification at the specified time
        var currentUserId = Meteor.userId();                                                                       // 11
        var s1 = Meteor.users.find({ _id: currentUserId }).fetch()[0].notifData;                                   // 12
        var len = s1.length;                                                                                       // 13
        var s2 = s1[len - 1].timestamp;                                                                            // 14
                                                                                                                   //
        PastReminders.insert({                                                                                     // 16
            badge: badge,                                                                                          // 17
            addedAt: s2                                                                                            // 18
        }, function (error, result) {                                                                              // 16
            if (!error) {                                                                                          // 20
                Push.send({                                                                                        // 21
                    from: 'MHB',                                                                                   // 22
                    title: 'Reminder',                                                                             // 23
                    text: 'Just a friendly reminder that you need to take your medication!',                       // 24
                    badge: badge,                                                                                  // 25
                    payload: {                                                                                     // 26
                        title: 'Reminder',                                                                         // 27
                        historyId: result                                                                          // 28
                    },                                                                                             // 26
                    query: {}                                                                                      // 30
                });                                                                                                // 21
            }                                                                                                      // 32
        });                                                                                                        // 33
    },                                                                                                             // 34
    removeHistory: function removeHistory() {                                                                      // 35
        PastReminders.remove({}, function (error) {                                                                // 36
            if (!error) {                                                                                          // 37
                console.log("All past reminders removed");                                                         // 38
            }                                                                                                      // 39
        });                                                                                                        // 40
    }                                                                                                              // 41
});                                                                                                                // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"main.js":["meteor/meteor","meteor/http",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var HTTP;module.import('meteor/http',{"HTTP":function(v){HTTP=v}});
                                                                                                                   // 2
                                                                                                                   //
function _send_info() {                                                                                            // 5
        var PatientsInfo = Meteor.users.find().fetch();                                                            // 6
        console.log("sending Patients Information");                                                               // 7
                                                                                                                   //
        // This url serves as a web API. You can choose your own path to form a protocol.                          //
        // Notice that I use JSON as content type, you can use other content type according to your need.          //
        // Also, make sure to run the receiver app on port 3002.                                                   //
        var url = "http://localhost:3002/patients-update";                                                         // 12
        var result = HTTP.post(url, {                                                                              // 13
                headers: {                                                                                         // 14
                        "content-type": "application/json; charset=UTF-8"                                          // 15
                },                                                                                                 // 14
                content: JSON.stringify(PatientsInfo)                                                              // 17
        });                                                                                                        // 13
        console.log("Patients Information sended");                                                                // 19
}                                                                                                                  // 20
                                                                                                                   //
var c_Methods = {                                                                                                  // 22
        send_info: function send_info(arg) {                                                                       // 23
                _send_info();                                                                                      // 24
        }                                                                                                          // 25
};                                                                                                                 // 22
                                                                                                                   //
Router.route("/patients-update", { where: "server" }).post(function () {                                           // 28
        // retrieve data                                                                                           //
        var patients = this.request.body;                                                                          // 30
        // needs to end with a response so the other server doesn't hang.                                          //
        this.response.end("Patients recieved");                                                                    // 32
                                                                                                                   //
        for (var i = 0; i < patients.length; i++) {                                                                // 34
                Meteor.users.update({ _id: patients[i]["_id"] }, { $set: {                                         // 35
                                profile: patients[i]["profile"] }                                                  // 36
                });                                                                                                // 35
        }                                                                                                          // 38
});                                                                                                                // 39
                                                                                                                   //
Meteor.startup(function () {                                                                                       // 41
        // Register a meteor method for the client to call on.                                                     //
        Meteor.methods(c_Methods);                                                                                 // 43
});                                                                                                                // 44
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"startup":{"routes.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// startup/routes.js                                                                                               //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// routes.js                                                                                                       //
if (Meteor.isClient) {                                                                                             // 2
  Router.onBeforeAction(function () {                                                                              // 3
    // all properties available in the route function                                                              //
    // are also available here such as this.params                                                                 //
                                                                                                                   //
    if (!Meteor.userId()) {                                                                                        // 7
      // if the user is not logged in, render the Login template                                                   //
                                                                                                                   //
      this.render('login');                                                                                        // 10
    } else {                                                                                                       // 11
      // otherwise don't hold up the rest of hooks or our route/action function                                    //
      // from running                                                                                              //
      this.next();                                                                                                 // 14
    }                                                                                                              // 15
  });                                                                                                              // 16
}                                                                                                                  // 17
                                                                                                                   //
Router.route('/home', function () {                                                                                // 20
  this.render('home');                                                                                             // 21
  Meteor.call("send_info");                                                                                        // 22
});                                                                                                                // 23
                                                                                                                   //
Router.route('/helppage', function () {                                                                            // 26
  this.render('helppage');                                                                                         // 27
});                                                                                                                // 28
                                                                                                                   //
Router.route('/profile', function () {                                                                             // 30
  this.render('profile');                                                                                          // 31
});                                                                                                                // 32
                                                                                                                   //
Router.route('/myprogress', function () {                                                                          // 34
  this.render('myprogress');                                                                                       // 35
});                                                                                                                // 36
                                                                                                                   //
Router.route('/mylearningpage', function () {                                                                      // 38
  this.render('mylearningpage');                                                                                   // 39
});                                                                                                                // 40
Router.route('/mymedspage', function () {                                                                          // 41
  this.render('mymedspage');                                                                                       // 42
});                                                                                                                // 43
Router.route('/mysurveypage', function () {                                                                        // 44
  this.render('mysurveypage');                                                                                     // 45
});                                                                                                                // 46
Router.route('/helpInstructions', function () {                                                                    // 47
  this.render('helpInstructions');                                                                                 // 48
});                                                                                                                // 49
Router.route('/warfarin/', function () {                                                                           // 50
  this.render('mylearningWarfarin');                                                                               // 51
});                                                                                                                // 52
Router.route('/othermeds/', function () {                                                                          // 53
  this.render('mylearningOtherMeds');                                                                              // 54
});                                                                                                                // 55
Router.route('/warning/', function () {                                                                            // 56
  this.render('mylearningWarning');                                                                                // 57
});                                                                                                                // 58
                                                                                                                   //
Router.route('/safetytips/', function () {                                                                         // 61
  this.render('mylearningSafety');                                                                                 // 62
});                                                                                                                // 63
                                                                                                                   //
Router.route('/setupPushReminder/', function () {                                                                  // 65
  this.render('setupPushReminder');                                                                                // 66
});                                                                                                                // 67
Router.route('/addReminder/', function () {                                                                        // 68
  this.render('addReminder');                                                                                      // 69
});                                                                                                                // 70
                                                                                                                   //
// Router.route('mylearningWarfarin', {                                                                            //
//   // get parameter via this.params                                                                              //
//   path: '/mylearningpage/warfarin'                                                                              //
// });                                                                                                             //
                                                                                                                   //
// Router.route('mylearningWarfarinDiet', {                                                                        //
//   path: '/mylearningpage/diet'                                                                                  //
// });                                                                                                             //
Router.route('/addinr', function () {                                                                              // 80
  this.render('addinr');                                                                                           // 81
});                                                                                                                // 82
                                                                                                                   //
Router.route('/thankyou', function () {                                                                            // 84
  this.render('thankyou');                                                                                         // 85
});                                                                                                                // 86
                                                                                                                   //
Router.route('/inrhistory', function () {                                                                          // 88
  this.render('inrhistory');                                                                                       // 89
});                                                                                                                // 90
Router.route('/medhistory', function () {                                                                          // 91
  this.render('medhistory');                                                                                       // 92
});                                                                                                                // 93
Router.route('/mealshistory', function () {                                                                        // 94
  this.render('mealshistory');                                                                                     // 95
});                                                                                                                // 96
Router.route('/video', function () {                                                                               // 97
  this.render('video');                                                                                            // 98
});                                                                                                                // 99
                                                                                                                   //
Router.route('/contact', function () {                                                                             // 101
  this.render('contact');                                                                                          // 102
});                                                                                                                // 103
Router.route('/aboutus', function () {                                                                             // 104
  this.render('aboutus');                                                                                          // 105
});                                                                                                                // 106
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/reminderdb.js");
require("./server/api/Login.js");
require("./server/api/account-creation.js");
require("./server/api/pushMethods.js");
require("./startup/routes.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
